# Rendu CLASSIFICATION pour la SAÉ S3.02

!!! abstract Groupe J4
    Renan Declercq
    Clément Delerue
    Pierre Dereu 
    Bastien Leleu

!!! abstract Repo Gitlab
    - <https://gitlab.univ-lille.fr/sae302/2022/equipe-J4.git>

## 1. Table des matières


<!-- @import "[TOC]" {cmd="toc" depthFrom=1 depthTo=6 orderedList=false} -->

<!-- code_chunk_output -->

- [Rendu CLASSIFICATION pour la SAÉ S3.02](#rendu-classification-pour-la-saé-s302)
  - [1. Table des matières](#1-table-des-matières)
  - [2. Analyse des données](#2-analyse-des-données)
    - [2.1 Chargement des données et préparation des données](#21-chargement-des-données-et-préparation-des-données)
    - [2.2 Les distances](#22-les-distances)
    - [2.3 La normalisation](#23-la-normalisation)
  - [3. Implémentation de k-NN](#3-implémentation-de-k-nn)
  - [4. Robustesse des modèles](#4-robustesse-des-modèles)
  - [5. Participation](#5-participation)

<!-- /code_chunk_output -->


## 2. Analyse des données

### 2.1 Chargement des données et préparation des données


!!! abstract Contenu du package `input`
    !!! abstract Interfaces
        - ICSVReader : Transforme un CSV en une liste d'IPointBrut
        - IPointBrut : Interface vide qui sert à rendre générique ICSVReader 

    !!! abstract Classes concrètes
        - IrisCSVReader implemente ICSVReader : Transforme un CSV avec les données d'iris en une liste d'iris brutes
        - PassengerCSVReader implemente ICSVReader : Transforme un CSV avec les données de passagers en une liste de passagers bruts
        - IrisBrut implemente IPointBrut 
        - PassengerBrut implemente IPointBrut


!!! abstract Contenu du package `factory`
    !!! abstract Interfaces
        - IFactory : Permet de convertir les points bruts en points 

    !!! abstract Classes concrètes
        - IrisFactory implemente IFactory : Ici, on transforme la valeur `Double` de l'attribut `hasSurvived` en une enum ainsi que la valeur `String` de l'attribut passengerSex en une enum
        - PassengerFactory implemente IFactory : Ici, on transforme la valeur `String` de l'attribut `variety` en une enum

!!! abstract Contenu du package `point`
    !!! abstract Interfaces
        - IPoint : Représente les objets que l'on classifie de façon générique
        - IClassificationValue : Interface vide qui sert à rendre générique la valeur de la classification

    !!! abstract Classes concrètes
        - Iris implement IPoint
        - Passenger implement IPoint

    !!! abstract enum
        - IrisVariety implement IClassificationValue ( = La classification des iris )
        - PassengerHasSurvivedOrNot implement IClassificationValue ( = La classification des passagers )
        - PassengerSex 

### 2.2 Les distances

!!! abstract Contenu du package `distance`
    !!! abstract Classe abstraite
        - Distance : classe abstraite générique permettant le calcul d'une distance entre deux points, normalisé ou non.

    !!! abstract Classes concrètes
        - DistanceIris hérite de Distance
        - DistancePassenger hérite de Distance

    !!! abstract enum
        - DistanceAlgorithm : Une énum des algorithmes de distance possibles (Manhattan , Euclidienne et Aléatoire).

    !!! note
        Par défaut, c'est la distance normalisée de Manhattan qui est sélectionnée.
    

### 2.3 La normalisation

!!! abstract Contenu du package `normalizer`

    !!! abstract Interface
        - IValueNormalizer : Définit des methodes de normalisation et de dénormalisation 

    !!! abstract Classe concrète 
        - NumberNormalizer implemente IValueNormalizer : Permet de normaliser et de dénormaliser des valeurs numériques par rapport à l'ensemble des valeurs du jeu de données d'entrainement présentent dans la colonne

!!! abstract Contenu du package `column`

    !!! abstract Interface
        - IColumn : Définit une colonne

    !!! abstract Classes concrètes
        - ColumnNumber implemente IColumn : Définit une colonne avec des valeurs numériques (normalisables)
        - ColumnString implemente IColumn : Définit une colonne avec des valeurs en chaines de caractères (non normalisables)

    !!! abstract Enum
        - ColumnNumberAttribute implemente TransformToNumber : C'est grâce à cette enum qu'on peut récuperer la valeur d'un point spécifique à une colonne. Cet enum permet l'utilisation du polymorphisme des classes concrètes `Column` , nous avons aussi rajouté des coefficients pour donner plus de poids à certains attributs dans le calcul des distances.
        - ColumnStringAttrivute implemente TransformToString : même chose mais pour les attributs en chaine de caractères
        - DataType : Spécifie le type de donnée (point)
    
!!! abstract Contenu du package `dataset`

    !!! abstract Interface
        - IDataset : Définit un dataset 

    !!! abstract Classe concrète
        - Dataset implemente IDataset : Réprésente une liste de points sur laquelle on peut intéragir 

## 3. Implémentation de k-NN

!!! abstract Contenu du package `classifier`

    !!! abstract Classe abstraite
        Classifier : Représente la classe de classification de façon générique. Elle détermine les K plus proches voisins d'un point à l'aide d'un algorithme de distance définit. Cela permet donc de classifier les points grâce aux résultats obtenus des K plus proche voisins.


    !!! abstract Classe concrète
        - Dataset implemente IDataset : Réprésente une liste de points sur laquelle on peut intéragir 

!!! tip Les coefficients
    Nous avons étudier les jeux de données d'entrainement fournis pour déterminer les colonnes les plus pertinentes dans les calculs de distance. 
    
    !!! Example Iris
        Nous avons ainsi choisi d'attribuer : 
        - Un poid plus élevé pour la colonne `PETAL_LENGTH` car les valeurs sont très significatives et représentatives de la variété
        - Un poid intermédiaire pour la colonne `PETAL_WIDTH` 
        - Un poid plus faible pour les colonnes `SEPAL_LENGTH` et `SEPAL_WIDTH` car les valeurs sont moins significatives et représentatives de la variété, il y a donc des risques de s'approcher trop des valeurs d'autres 
        
    !!! Example Passager
        Nous avons ainsi choisi d'attribuer : 
        - Un poid plus élevé pour les colonne `PASSENGER_SEX` et `PASSENGER_AGE`car les valeurs sont très significatives et représentatives de la survie ou non d'un passager.

!!! tip Les colonnes ignorées
    Nous avons aussi décidé d'ignorer certaines colonnes du calcul des distances entre deux points car elles nous semblaient pas pertinentes.
    
    !!! example Passager
        Nous avons retiré du calcul les colonnes suivantes :
        - `PASSENGER_NAME` 
        - `PASSENGER_TICKET_LABEL`
        - `PASSENGER_ID`




## 4. Robustesse des modèles

!!! abstract Contenu du package `robustness`

    !!! abstract Classe abstraite
        Robustness : Représente la classe de robustesse de façon générique. Elle détermine la robustesse de la classification. Pour cela, nous prenons le jeu de données d'entrainement que nous divisons en deux listes. 
        - La liste des points de tests
        - La liste des points d'entrainement qui rep
        Elle permet aussi de trouver le meilleur k possible, pour cela , elle calcule toutes les robustesses pour chaque k possible et renvoie la meilleur robustesse, nous calculons ensuite la robustesse pour chaque k jusqu'à ce qu'elle retourne la meilleure robustesse possible et retourne le k associé à cette robustesse.



    !!! abstract Classe concrète
        - IrisRobustness hérite de Robustness : classe concrète pour la robustesse de la classification des iris
        - PassengerRobustness hérite de Robustness : classe concrète pour la robustesse de la classification des passagers

!!! note
    Nous avons choisi de limiter la valeur maximale pour k car nous ne voulons généralement pas un k trop grand pour éviter la perte de précision. De plus cela nous permet d'éviter les trop mauvaises performances en limitant les tours de boucles trop élevés.

Ci-dessous l'éxecution de la classe `RobustnessDemo` permettant d'obtenir les informations concernant la robustesse de nos classifications

!!! example Robustesse des iris (Distance de Manhattan normalisée)
    <img src="./images/robustesse-iris.png">

!!!example Robustesse des passagers (Distance de Manhattan normalisée)
    <img src="./images/robustesse-passenger.png">


## 5. Participation

 | Prénom Nom  |  Participation |
|---|---|
| Renan Declercq  | Participation aux réflections communes de l'implémentation - TP pokemon - Participation à l'implémentation du code sur l'ensemble du modèle - Refactoring du code - Résolution de bugs - Code coverage - Rédaction du rapport|
| Clément Delerue  | Participation aux réflections communes de l'implémentation du modèle - TP pokemon - Participation à l'implémentation du code dans les packages column et classifier - Réalisation des controlleurs et vues (utilisation de SceneBuilder) |
| Pierre Dereu  | Participation aux réflections communes de l'implémentation - TP pokemon - Réalisation des tests + résolution des bugs - Pattern NullObject - Code coverage |
| Bastien Leleu  | Participation aux réflections communes de l'implémentation - TP pokemon - Réalisation des tests + résolution des bugs - Code coverage|
